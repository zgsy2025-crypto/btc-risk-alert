import os
import time
import math
import requests
from datetime import datetime, timezone

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")
SYMBOL = os.getenv("SYMBOL", "BTCUSDT")
CHECK_INTERVAL = int(os.getenv("CHECK_INTERVAL", "60"))  # seconds
COOLDOWN_MINUTES = int(os.getenv("COOLDOWN_MINUTES", "15"))

# Alert thresholds
DROP_5M = float(os.getenv("DROP_5M", "-1.5"))
DROP_15M = float(os.getenv("DROP_15M", "-3.0"))
DROP_60M = float(os.getenv("DROP_60M", "-5.0"))
PUMP_5M = float(os.getenv("PUMP_5M", "1.8"))
VOLUME_SPIKE_MULTIPLIER = float(os.getenv("VOLUME_SPIKE_MULTIPLIER", "2.5"))
RSI_OVERBOUGHT = float(os.getenv("RSI_OVERBOUGHT", "75"))
RSI_OVERSOLD = float(os.getenv("RSI_OVERSOLD", "25"))

last_alert_time = {}


def now_utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def send_telegram(message: str):
    if not TELEGRAM_BOT_TOKEN or not CHAT_ID:
        print("Missing TELEGRAM_BOT_TOKEN or CHAT_ID")
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": CHAT_ID,
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    try:
        r = requests.post(url, json=payload, timeout=15)
        if r.status_code != 200:
            print("Telegram error:", r.status_code, r.text)
    except Exception as e:
        print("Telegram exception:", e)


def should_alert(key: str) -> bool:
    current = time.time()
    cooldown = COOLDOWN_MINUTES * 60
    if key not in last_alert_time or current - last_alert_time[key] > cooldown:
        last_alert_time[key] = current
        return True
    return False


def get_bybit_klines(interval="1", limit=240):
    url = "https://api.bybit.com/v5/market/kline"
    params = {
        "category": "linear",
        "symbol": SYMBOL,
        "interval": interval,
        "limit": limit,
    }
    r = requests.get(url, params=params, timeout=15)
    r.raise_for_status()
    data = r.json()
    if data.get("retCode") != 0:
        raise RuntimeError(data)
    candles = data["result"]["list"]
    # Bybit returns newest first. Reverse to oldest first.
    candles = list(reversed(candles))
    parsed = []
    for c in candles:
        parsed.append({
            "ts": int(c[0]),
            "open": float(c[1]),
            "high": float(c[2]),
            "low": float(c[3]),
            "close": float(c[4]),
            "volume": float(c[5]),
        })
    return parsed


def pct_change(current, previous):
    if previous == 0:
        return 0.0
    return (current - previous) / previous * 100


def ema(values, period):
    if not values:
        return None
    k = 2 / (period + 1)
    e = values[0]
    for v in values[1:]:
        e = v * k + e * (1 - k)
    return e


def rsi(values, period=14):
    if len(values) < period + 1:
        return None
    gains, losses = [], []
    for i in range(1, len(values)):
        diff = values[i] - values[i - 1]
        gains.append(max(diff, 0))
        losses.append(abs(min(diff, 0)))
    avg_gain = sum(gains[-period:]) / period
    avg_loss = sum(losses[-period:]) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def format_price(p):
    return f"${p:,.2f}"


def analyze_and_alert():
    candles_1m = get_bybit_klines("1", 240)
    closes = [c["close"] for c in candles_1m]
    volumes = [c["volume"] for c in candles_1m]
    current = closes[-1]

    chg_5m = pct_change(current, closes[-6]) if len(closes) >= 6 else 0
    chg_15m = pct_change(current, closes[-16]) if len(closes) >= 16 else 0
    chg_60m = pct_change(current, closes[-61]) if len(closes) >= 61 else 0

    rsi_14 = rsi(closes[-50:], 14)
    ema_200 = ema(closes[-200:], 200) if len(closes) >= 200 else None

    recent_vol = volumes[-1]
    avg_vol_30 = sum(volumes[-31:-1]) / 30 if len(volumes) >= 31 else recent_vol
    volume_spike = avg_vol_30 > 0 and recent_vol >= avg_vol_30 * VOLUME_SPIKE_MULTIPLIER

    base = (
        f"<b>BTC Guardian v1</b>\n"
        f"시간: {now_utc()}\n"
        f"현재가: <b>{format_price(current)}</b>\n"
        f"5분: {chg_5m:.2f}% | 15분: {chg_15m:.2f}% | 1시간: {chg_60m:.2f}%\n"
        f"RSI(14): {rsi_14:.1f}" if rsi_14 is not None else ""
    )

    if chg_5m <= DROP_5M and should_alert("drop_5m"):
        send_telegram(
            f"🚨 <b>BTC 5분 급락 경고</b>\n\n"
            f"현재가: <b>{format_price(current)}</b>\n"
            f"5분 변동률: <b>{chg_5m:.2f}%</b>\n\n"
            f"주의: 신규 롱 진입 금지/레버리지 축소 검토\n"
            f"Bybit: https://www.bybit.com/trade/usdt/{SYMBOL}\n"
            f"TradingView: https://www.tradingview.com/symbols/BTCUSDT/"
        )

    if chg_15m <= DROP_15M and should_alert("drop_15m"):
        send_telegram(
            f"🩸 <b>BTC 15분 강한 급락 경고</b>\n\n"
            f"현재가: <b>{format_price(current)}</b>\n"
            f"15분 변동률: <b>{chg_15m:.2f}%</b>\n\n"
            f"주의: 손실 복구성 진입 금지. 청산가 근접 포지션 확인."
        )

    if chg_60m <= DROP_60M and should_alert("drop_60m"):
        send_telegram(
            f"🚨🚨 <b>BTC 1시간 패닉성 변동 경고</b>\n\n"
            f"현재가: <b>{format_price(current)}</b>\n"
            f"1시간 변동률: <b>{chg_60m:.2f}%</b>\n\n"
            f"대응: 신규 선물 진입보다 계좌 보호 우선."
        )

    if chg_5m >= PUMP_5M and should_alert("pump_5m"):
        send_telegram(
            f"🔥 <b>BTC 5분 급등/추격매수 주의</b>\n\n"
            f"현재가: <b>{format_price(current)}</b>\n"
            f"5분 변동률: <b>{chg_5m:.2f}%</b>\n\n"
            f"주의: FOMO 추격 롱 금지. 눌림/손절 기준 없으면 관망."
        )

    if volume_spike and should_alert("volume_spike"):
        send_telegram(
            f"⚠️ <b>BTC 거래량 급증 감지</b>\n\n"
            f"현재가: <b>{format_price(current)}</b>\n"
            f"최근 1분 거래량이 30분 평균 대비 <b>{recent_vol / avg_vol_30:.1f}배</b>입니다.\n\n"
            f"주의: 변동성 확대 가능. 선물 신규 진입 전 대기 권장."
        )

    if rsi_14 is not None and rsi_14 >= RSI_OVERBOUGHT and should_alert("rsi_overbought"):
        send_telegram(
            f"🔥 <b>BTC RSI 과열 경고</b>\n\n"
            f"현재가: <b>{format_price(current)}</b>\n"
            f"RSI(14): <b>{rsi_14:.1f}</b>\n\n"
            f"주의: 추격매수보다 손익비 확인 우선."
        )

    if rsi_14 is not None and rsi_14 <= RSI_OVERSOLD and should_alert("rsi_oversold"):
        send_telegram(
            f"🟢 <b>BTC 단기 과매도 관심 구간</b>\n\n"
            f"현재가: <b>{format_price(current)}</b>\n"
            f"RSI(14): <b>{rsi_14:.1f}</b>\n\n"
            f"주의: 즉시 매수 신호 아님. 반등 확인 전 고레버리지 금지."
        )

    if ema_200 is not None and current < ema_200 and should_alert("below_ema200"):
        send_telegram(
            f"📉 <b>BTC 단기 추세 약화</b>\n\n"
            f"현재가: <b>{format_price(current)}</b>\n"
            f"1분봉 EMA200: <b>{format_price(ema_200)}</b>\n\n"
            f"주의: 추세 회복 전 롱 진입 보수적으로 판단."
        )

    print(f"{now_utc()} | {SYMBOL} {format_price(current)} | 5m {chg_5m:.2f}% | 15m {chg_15m:.2f}% | 60m {chg_60m:.2f}%")


def main():
    send_telegram("🟢 <b>BTC Guardian v1 시작</b>\n\n자동매매 없음. 위험 알림만 전송합니다.")
    while True:
        try:
            analyze_and_alert()
        except Exception as e:
            print("Error:", e)
            if should_alert("system_error"):
                send_telegram(f"⚠️ BTC Guardian 오류 발생\n{e}")
        time.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    main()
