# BTC Risk Alert / BTC Guardian v1

Telegram으로 BTC 위험 신호를 보내는 알림봇입니다.

## 기능
- BTC 5분/15분/1시간 급등락 감지
- 거래량 급증 감지
- RSI 과열/과매도 감지
- EMA200 단기 추세 약화 감지
- 자동매매 없음, 알림만 전송

## Render 설정

Build Command:
```bash
pip install -r requirements.txt
```

Start Command:
```bash
python btc_guardian.py
```

Environment Variables:
- TELEGRAM_BOT_TOKEN = BotFather에서 받은 토큰
- CHAT_ID = 본인의 Telegram Chat ID

선택 설정:
- SYMBOL = BTCUSDT
- CHECK_INTERVAL = 60
- COOLDOWN_MINUTES = 15
